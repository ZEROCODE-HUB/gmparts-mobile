/*
 * Copyright 2020 https://github.com/TercyoStorck
 *
 * Source code has been modified by FlutterFlow, Inc.
 * 
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 * 
 * 1. Redistributions of source code must retain the above copyright notice, 
 * this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright notice, 
 * this list of conditions and the following disclaimer in the 
 * documentation and/or other materials provided with the distribution.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS 
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED 
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE 
 * USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

import 'form_field_controller.dart';
import 'package:flutter/material.dart';
import 'flutter_flow_widgets.dart';

class FlutterFlowRadioButton extends StatefulWidget {
  const FlutterFlowRadioButton({
    super.key,
    required this.options,
    required this.onChanged,
    required this.controller,
    this.optionHeight,
    required this.textStyle,
    this.optionWidth,
    this.selectedTextStyle,
    this.textPadding = EdgeInsets.zero,
    this.buttonPosition = RadioButtonPosition.left,
    this.direction = Axis.vertical,
    required this.radioButtonColor,
    this.inactiveRadioButtonColor,
    this.toggleable = false,
    this.horizontalAlignment = WrapAlignment.start,
    this.verticalAlignment = WrapCrossAlignment.start,
    this.focusBorder,
    this.focusBorderRadius,
    this.focusBorderPadding,
    this.showBorderAroundRadioButtonAndText = true,
    this.optionSpacing,
  });

  final List<String> options;
  final Function(String?)? onChanged;
  final FormFieldController<String> controller;
  final double? optionHeight;
  final double? optionWidth;
  final double? optionSpacing;
  final TextStyle textStyle;
  final TextStyle? selectedTextStyle;
  final EdgeInsetsGeometry textPadding;
  final RadioButtonPosition buttonPosition;
  final Axis direction;
  final Color radioButtonColor;
  final Color? inactiveRadioButtonColor;
  final bool toggleable;
  final WrapAlignment horizontalAlignment;
  final WrapCrossAlignment verticalAlignment;
  final Border? focusBorder;
  final BorderRadius? focusBorderRadius;
  final EdgeInsetsGeometry? focusBorderPadding;
  final bool showBorderAroundRadioButtonAndText;

  @override
  State<FlutterFlowRadioButton> createState() => _FlutterFlowRadioButtonState();
}

class _FlutterFlowRadioButtonState extends State<FlutterFlowRadioButton> {
  bool get enabled => widget.onChanged != null;
  FormFieldController<String> get controller => widget.controller;
  void Function()? _listener;

  @override
  void initState() {
    super.initState();
    _maybeSetOnChangedListener();
  }

  @override
  void dispose() {
    _maybeRemoveOnChangedListener();
    super.dispose();
  }

  @override
  void didUpdateWidget(FlutterFlowRadioButton oldWidget) {
    super.didUpdateWidget(oldWidget);
    final oldWidgetEnabled = oldWidget.onChanged != null;
    if (oldWidgetEnabled != enabled) {
      _maybeRemoveOnChangedListener();
      _maybeSetOnChangedListener();
    }
  }

  void _maybeSetOnChangedListener() {
    if (enabled) {
      _listener = () => widget.onChanged!(controller.value);
      controller.addListener(_listener!);
    }
  }

  void _maybeRemoveOnChangedListener() {
    if (_listener != null) {
      controller.removeListener(_listener!);
      _listener = null;
    }
  }

  List<String> get effectiveOptions =>
      widget.options.isEmpty ? ['[Option]'] : widget.options;

  @override
  Widget build(BuildContext context) {
    return Theme(
      data: Theme.of(context)
          .copyWith(unselectedWidgetColor: widget.inactiveRadioButtonColor),
      child: RadioGroup<String>.builder(
        direction: widget.direction,
        groupValue: controller.value,
        onChanged: enabled ? (value) => controller.value = value : null,
        activeColor: widget.radioButtonColor,
        toggleable: widget.toggleable,
        textStyle: widget.textStyle,
        selectedTextStyle: widget.selectedTextStyle ?? widget.textStyle,
        textPadding: widget.textPadding,
        optionHeight: widget.optionHeight,
        optionWidth: widget.optionWidth,
        optionSpacing: widget.optionSpacing,
        horizontalAlignment: widget.horizontalAlignment,
        verticalAlignment: widget.verticalAlignment,
        items: effectiveOptions,
        itemBuilder: (item) =>
            RadioButtonBuilder(item, buttonPosition: widget.buttonPosition),
        focusBorder: widget.focusBorder,
        focusBorderRadius: widget.focusBorderRadius,
        focusBorderPadding: widget.focusBorderPadding,
        showBorderAroundRadioButtonAndText:
            widget.showBorderAroundRadioButtonAndText,
      ),
    );
  }
}

enum RadioButtonPosition {
  right,
  left,
}

class RadioButtonBuilder<T> {
  RadioButtonBuilder(
    this.description, {
    this.buttonPosition = RadioButtonPosition.left,
  });

  final String description;
  final RadioButtonPosition buttonPosition;
}

class RadioButton<T> extends StatelessWidget {
  const RadioButton({
    super.key,
    required this.description,
    required this.value,
    required this.groupValue,
    required this.onChanged,
    required this.buttonPosition,
    required this.activeColor,
    required this.toggleable,
    required this.textStyle,
    required this.selectedTextStyle,
    required this.textPadding,
    this.shouldFlex = false,
    this.focusBorder,
    this.focusBorderRadius,
    this.focusBorderPadding,
    this.showBorderAroundRadioButtonAndText = true,
  });

  final String description;
  final T value;
  final T? groupValue;
  final void Function(T?)? onChanged;
  final RadioButtonPosition buttonPosition;
  final Color activeColor;
  final bool toggleable;
  final TextStyle textStyle;
  final TextStyle selectedTextStyle;
  final EdgeInsetsGeometry textPadding;
  final bool shouldFlex;
  final Border? focusBorder;
  final BorderRadius? focusBorderRadius;
  final EdgeInsetsGeometry? focusBorderPadding;
  final bool showBorderAroundRadioButtonAndText;

  Widget _buildRadio(FocusNode? focusNode) {
    return Radio<T>(
      groupValue: groupValue,
      onChanged: onChanged,
      value: value,
      activeColor: activeColor,
      toggleable: toggleable,
      focusNode: focusNode,
    );
  }

  @override
  Widget build(BuildContext context) {
    final selectedStyle = selectedTextStyle;
    final isSelected = value == groupValue;
    Widget radioButtonText = Padding(
      padding: textPadding,
      child: Text(
        description,
        style: isSelected ? selectedStyle : textStyle,
      ),
    );
    if (shouldFlex) {
      radioButtonText = Flexible(child: radioButtonText);
    }

    final hasFocusBorder = focusBorder != null ||
        focusBorderRadius != null ||
        focusBorderPadding != null;

    if (hasFocusBorder && showBorderAroundRadioButtonAndText) {
      return FFFocusIndicator(
        border: focusBorder,
        borderRadius: focusBorderRadius,
        padding: focusBorderPadding,
        builder: (focusNode) => GestureDetector(
          onTap: onChanged != null ? () => onChanged!(value) : null,
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              if (buttonPosition == RadioButtonPosition.right) radioButtonText,
              _buildRadio(focusNode),
              if (buttonPosition == RadioButtonPosition.left) radioButtonText,
            ],
          ),
        ),
      );
    }

    Widget radioWidget;
    if (hasFocusBorder && !showBorderAroundRadioButtonAndText) {
      radioWidget = FFFocusIndicator(
        border: focusBorder,
        borderRadius: focusBorderRadius,
        padding: focusBorderPadding,
        builder: (focusNode) => _buildRadio(focusNode),
      );
    } else {
      radioWidget = _buildRadio(null);
    }

    return GestureDetector(
      onTap: onChanged != null ? () => onChanged!(value) : null,
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          if (buttonPosition == RadioButtonPosition.right) radioButtonText,
          radioWidget,
          if (buttonPosition == RadioButtonPosition.left) radioButtonText,
        ],
      ),
    );
  }
}

class RadioGroup<T> extends StatelessWidget {
  const RadioGroup.builder({
    super.key,
    required this.groupValue,
    required this.onChanged,
    required this.items,
    required this.itemBuilder,
    required this.direction,
    this.optionHeight,
    required this.horizontalAlignment,
    required this.activeColor,
    required this.toggleable,
    required this.textStyle,
    required this.selectedTextStyle,
    required this.textPadding,
    this.optionWidth,
    this.verticalAlignment = WrapCrossAlignment.center,
    this.focusBorder,
    this.focusBorderRadius,
    this.focusBorderPadding,
    this.showBorderAroundRadioButtonAndText = true,
    this.optionSpacing,
  });

  final T? groupValue;
  final List<T> items;
  final RadioButtonBuilder Function(T value) itemBuilder;
  final void Function(T?)? onChanged;
  final Axis direction;
  final double? optionHeight;
  final double? optionWidth;
  final double? optionSpacing;
  final WrapAlignment horizontalAlignment;
  final WrapCrossAlignment verticalAlignment;
  final Color activeColor;
  final bool toggleable;
  final TextStyle textStyle;
  final TextStyle selectedTextStyle;
  final EdgeInsetsGeometry textPadding;
  final Border? focusBorder;
  final BorderRadius? focusBorderRadius;
  final EdgeInsetsGeometry? focusBorderPadding;
  final bool showBorderAroundRadioButtonAndText;

  List<Widget> get _group => items.map(
        (item) {
          final radioButtonBuilder = itemBuilder(item);
          return SizedBox(
            height: optionHeight,
            width: optionWidth,
            child: RadioButton(
              description: radioButtonBuilder.description,
              value: item,
              groupValue: groupValue,
              onChanged: onChanged,
              buttonPosition: radioButtonBuilder.buttonPosition,
              activeColor: activeColor,
              toggleable: toggleable,
              textStyle: textStyle,
              selectedTextStyle: selectedTextStyle,
              textPadding: textPadding,
              shouldFlex: optionWidth != null,
              focusBorder: focusBorder,
              focusBorderRadius: focusBorderRadius,
              focusBorderPadding: focusBorderPadding,
              showBorderAroundRadioButtonAndText:
                  showBorderAroundRadioButtonAndText,
            ),
          );
        },
      ).toList();

  @override
  Widget build(BuildContext context) {
    final effectiveSpacing = optionSpacing ?? 0.0;
    return direction == Axis.horizontal
        ? Wrap(
            direction: direction,
            alignment: horizontalAlignment,
            spacing: effectiveSpacing,
            runSpacing: effectiveSpacing,
            children: _group,
          )
        : Wrap(
            direction: direction,
            crossAxisAlignment: verticalAlignment,
            spacing: effectiveSpacing,
            runSpacing: effectiveSpacing,
            children: _group,
          );
  }
}
