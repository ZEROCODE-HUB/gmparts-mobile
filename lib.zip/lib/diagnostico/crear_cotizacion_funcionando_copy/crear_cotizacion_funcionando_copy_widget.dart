import '/auth/firebase_auth/auth_util.dart';
import '/components/user_avatar_widget.dart';
import '/backend/backend.dart';
import '/components/fallacomponent_update_widget.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/index.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'crear_cotizacion_funcionando_copy_model.dart';
export 'crear_cotizacion_funcionando_copy_model.dart';

class CrearCotizacionFuncionandoCopyWidget extends StatefulWidget {
  const CrearCotizacionFuncionandoCopyWidget({
    super.key,
    required this.recepcion,
  });

  final RecepcionesRecord? recepcion;

  static String routeName = 'CrearCotizacionFuncionandoCopy';
  static String routePath = '/crearCotizacionFuncionandoCopy';

  @override
  State<CrearCotizacionFuncionandoCopyWidget> createState() =>
      _CrearCotizacionFuncionandoCopyWidgetState();
}

class _CrearCotizacionFuncionandoCopyWidgetState
    extends State<CrearCotizacionFuncionandoCopyWidget> {
  FlutterFlowTheme get _theme => FlutterFlowTheme.of(context);

  late CrearCotizacionFuncionandoCopyModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => CrearCotizacionFuncionandoCopyModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final _theme = FlutterFlowTheme.of(context);
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
        FocusManager.instance.primaryFocus?.unfocus();
      },
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: _theme.primaryBackground,
        body: SafeArea(
          top: true,
          child: Padding(
            padding: EdgeInsetsDirectional.fromSTEB(20.0, 20.0, 20.0, 0.0),
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Row(
                    mainAxisSize: MainAxisSize.max,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                        padding: EdgeInsetsDirectional.fromSTEB(
                            0.0, 10.0, 38.0, 0.0),
                        child: FlutterFlowIconButton(
                          borderColor: _theme.primary,
                          borderRadius: 30.0,
                          borderWidth: 1.0,
                          buttonSize: 32.0,
                          icon: Icon(
                            Icons.chevron_left_rounded,
                            color: _theme.primary,
                            size: 16.0,
                          ),
                          onPressed: () async {
                            context.safePop();
                          },
                        ),
                      ),
                      Padding(
                        padding:
                            EdgeInsetsDirectional.fromSTEB(0.0, 15.0, 0.0, 0.0),
                        child: Text(
                          'Detalle',
                          style: _theme
                              .titleLarge
                              .override(
                                font: GoogleFonts.montserrat(
                                  fontWeight: FontWeight.w500,
                                  fontStyle: _theme
                                      .titleLarge
                                      .fontStyle,
                                ),
                                color: _theme.primaryText,
                                letterSpacing: 0.0,
                                fontWeight: FontWeight.w500,
                                fontStyle: _theme
                                    .titleLarge
                                    .fontStyle,
                              ),
                        ),
                      ),
                      InkWell(
  onTap: () async {
    context.pushNamed(
      ACuentaWidget.routeName,
    );
  },
  child: Container(
                        width: 70.0,
                        decoration: BoxDecoration(),
                        child: Column(
                          mainAxisSize: MainAxisSize.max,
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Padding(
                              padding: EdgeInsetsDirectional.fromSTEB(
                                  0.0, 0.0, 0.0, 5.0),
                              child: AuthUserStreamWidget(
                                builder: (context) => Container(
                                  width: 32.0,
                                  height: 32.0,
                                  clipBehavior: Clip.antiAlias,
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                  ),
                                  child: UserAvatarWidget(size: 32.0),
                                ),
                              ),
                            ),
                            Align(
                              alignment: AlignmentDirectional(1.0, 0.0),
                              child: AuthUserStreamWidget(
                                builder: (context) => Text(
                                  valueOrDefault<String>(
                                    currentUserDisplayName,
                                    '-',
                                  ),
                                  textAlign: TextAlign.end,
                                  style: _theme
                                      .labelSmall
                                      .override(
                                        font: GoogleFonts.montserrat(
                                          fontWeight:
                                              _theme
                                                  .labelSmall
                                                  .fontWeight,
                                          fontStyle:
                                              _theme
                                                  .labelSmall
                                                  .fontStyle,
                                        ),
                                        letterSpacing: 0.0,
                                        fontWeight: _theme
                                            .labelSmall
                                            .fontWeight,
                                        fontStyle: _theme
                                            .labelSmall
                                            .fontStyle,
                                      ),
                                ),
                              ),
                            ),
                          
                                      Align(
                                        alignment: AlignmentDirectional(1.0, 0.0),
                                        child: Padding(
                                          padding: EdgeInsetsDirectional.fromSTEB(0.0, 2.0, 0.0, 0.0),
                                          child: Text(
                                            'Ver perfil',
                                            style: _theme.labelSmall.override(
                                              font: GoogleFonts.montserrat(fontSize: 10.0),
                                              fontSize: 10.0,
                                              color: _theme.primary,
                                            ),
                                          ),
                                        ),
                                      ),
],
                        ),
                      )
),
                    ],
                  ),
                  Padding(
                    padding:
                        EdgeInsetsDirectional.fromSTEB(0.0, 25.0, 0.0, 0.0),
                    child: Container(
                      width: double.infinity,
                      decoration: BoxDecoration(
                        color: _theme.accent2,
                        borderRadius: BorderRadius.circular(10.0),
                      ),
                      child: InkWell(
                        splashColor: Colors.transparent,
                        focusColor: Colors.transparent,
                        hoverColor: Colors.transparent,
                        highlightColor: Colors.transparent,
                        onTap: () async {
                          context.pushNamed(
                            BDetalleestaticoWidget.routeName,
                            queryParameters: {
                              'datos': serializeParam(
                                widget.recepcion,
                                ParamType.Document,
                              ),
                            }.withoutNulls,
                            extra: <String, dynamic>{
                              'datos': widget.recepcion,
                            },
                          );
                        },
                        child: Container(
                          decoration: BoxDecoration(),
                          child: Padding(
                            padding: EdgeInsetsDirectional.fromSTEB(
                                20.0, 20.0, 20.0, 20.0),
                            child: Column(
                              mainAxisSize: MainAxisSize.max,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Row(
                                  mainAxisSize: MainAxisSize.max,
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                      'Detalles de recepción',
                                      style: _theme
                                          .titleLarge
                                          .override(
                                            font: GoogleFonts.montserrat(
                                              fontWeight:
                                                  _theme
                                                      .titleLarge
                                                      .fontWeight,
                                              fontStyle:
                                                  _theme
                                                      .titleLarge
                                                      .fontStyle,
                                            ),
                                            letterSpacing: 0.0,
                                            fontWeight:
                                                _theme
                                                    .titleLarge
                                                    .fontWeight,
                                            fontStyle:
                                                _theme
                                                    .titleLarge
                                                    .fontStyle,
                                          ),
                                    ),
                                    Icon(
                                      Icons.arrow_circle_right_outlined,
                                      color:
                                          _theme.primary,
                                      size: 30.0,
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Padding(
                    padding:
                        EdgeInsetsDirectional.fromSTEB(0.0, 16.0, 0.0, 0.0),
                    child: StreamBuilder<List<DiagnosticosRecord>>(
                      stream: queryDiagnosticosRecord(
                        parent: widget.recepcion?.reference,
                        queryBuilder: (diagnosticosRecord) =>
                            diagnosticosRecord.orderBy('fecha'),
                      ),
                      builder: (context, snapshot) {
                        // Customize what your widget looks like when it's loading.
                        if (!snapshot.hasData) {
                          return Center(
                            child: SizedBox(
                              width: 50.0,
                              height: 50.0,
                              child: CircularProgressIndicator(
                                valueColor: AlwaysStoppedAnimation<Color>(
                                  _theme.primary,
                                ),
                              ),
                            ),
                          );
                        }
                        List<DiagnosticosRecord>
                            listViewDiagnosticosRecordList = snapshot.data!;

                        return ListView.separated(
                          padding: EdgeInsets.zero,
                          primary: false,
                          shrinkWrap: true,
                          scrollDirection: Axis.vertical,
                          itemCount: listViewDiagnosticosRecordList.length,
                          separatorBuilder: (_, __) => SizedBox(height: 16.0),
                          itemBuilder: (context, listViewIndex) {
                            final listViewDiagnosticosRecord =
                                listViewDiagnosticosRecordList[listViewIndex];
                            return wrapWithModel(
                              model: _model.fallacomponentUpdateModels.getModel(
                                listViewDiagnosticosRecord.reference.id,
                                listViewIndex,
                              ),
                              updateCallback: () => safeSetState(() {}),
                              updateOnChange: true,
                              child: FallacomponentUpdateWidget(
                                key: Key(
                                  'Key2q3_${listViewDiagnosticosRecord.reference.id}',
                                ),
                                indexx: listViewIndex,
                                recepcionRef:
                                    listViewDiagnosticosRecord.parentReference,
                                nombreFalla:
                                    listViewDiagnosticosRecord.nombreFalla,
                                servicioSolucion:
                                    listViewDiagnosticosRecord.solucion,
                                tiempoEstimado:
                                    listViewDiagnosticosRecord.tiempoEstimado,
                                fallaref: listViewDiagnosticosRecord,
                                actiontotal: () async {},
                              ),
                            );
                          },
                        );
                      },
                    ),
                  ),
                  Align(
                    alignment: AlignmentDirectional(0.0, 1.0),
                    child: Padding(
                      padding: EdgeInsetsDirectional.fromSTEB(
                          20.0, 20.0, 20.0, 20.0),
                      child: InkWell(
                        splashColor: Colors.transparent,
                        focusColor: Colors.transparent,
                        hoverColor: Colors.transparent,
                        highlightColor: Colors.transparent,
                        onTap: () async {
                          await DiagnosticosRecord.createDoc(
                                  widget.recepcion!.reference)
                              .set({
                            ...mapToFirestore(
                              {
                                'fecha': FieldValue.serverTimestamp(),
                              },
                            ),
                          });
                        },
                        child: Container(
                          width: double.infinity,
                          height: 45.0,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10.0),
                            border: Border.all(
                              color: _theme.primary,
                              width: 2.0,
                            ),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Spacer(),
                              Align(
                                alignment: AlignmentDirectional(0.0, 0.0),
                                child: Text(
                                  'Agregar nueva falla',
                                  style: _theme
                                      .headlineSmall
                                      .override(
                                        font: GoogleFonts.montserrat(
                                          fontWeight:
                                              _theme
                                                  .headlineSmall
                                                  .fontWeight,
                                          fontStyle:
                                              _theme
                                                  .headlineSmall
                                                  .fontStyle,
                                        ),
                                        letterSpacing: 0.0,
                                        fontWeight: _theme
                                            .headlineSmall
                                            .fontWeight,
                                        fontStyle: _theme
                                            .headlineSmall
                                            .fontStyle,
                                      ),
                                ),
                              ),
                              Flexible(
                                child: Align(
                                  alignment: AlignmentDirectional(1.0, 0.0),
                                  child: Padding(
                                    padding: EdgeInsetsDirectional.fromSTEB(
                                        0.0, 0.0, 10.0, 0.0),
                                    child: Icon(
                                      Icons.add_to_photos_sharp,
                                      color: _theme
                                          .primaryText,
                                      size: 24.0,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  Align(
                    alignment: AlignmentDirectional(0.0, 1.0),
                    child: Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(20.0, 0.0, 20.0, 20.0),
                      child: InkWell(
                        splashColor: Colors.transparent,
                        focusColor: Colors.transparent,
                        hoverColor: Colors.transparent,
                        highlightColor: Colors.transparent,
                        onTap: () async {
                          await widget.recepcion!.reference
                              .update(createRecepcionesRecordData(
                            status: FFAppConstants.Cotizacion,
                          ));

                          context.goNamed(
                            CotizacionFuncionandoWidget.routeName,
                            queryParameters: {
                              'recepcion': serializeParam(
                                widget.recepcion,
                                ParamType.Document,
                              ),
                            }.withoutNulls,
                            extra: <String, dynamic>{
                              'recepcion': widget.recepcion,
                            },
                          );
                        },
                        child: Container(
                          width: double.infinity,
                          height: 45.0,
                          decoration: BoxDecoration(
                            color: _theme.primary,
                            borderRadius: BorderRadius.circular(10.0),
                            border: Border.all(
                              color: _theme.primary,
                              width: 2.0,
                            ),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Align(
                                alignment: AlignmentDirectional(0.0, 0.0),
                                child: Text(
                                  'Crear cotización',
                                  style: _theme
                                      .headlineSmall
                                      .override(
                                        font: GoogleFonts.montserrat(
                                          fontWeight:
                                              _theme
                                                  .headlineSmall
                                                  .fontWeight,
                                          fontStyle:
                                              _theme
                                                  .headlineSmall
                                                  .fontStyle,
                                        ),
                                        letterSpacing: 0.0,
                                        fontWeight: _theme
                                            .headlineSmall
                                            .fontWeight,
                                        fontStyle: _theme
                                            .headlineSmall
                                            .fontStyle,
                                      ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
